presentation
=======================

```
Error in parse_block(g[-1], g[1], params.src) : 
  duplicate label 'figure2a'
```
